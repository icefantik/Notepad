helpWindowGeometry = "350x250"
textHelpWindow = ""