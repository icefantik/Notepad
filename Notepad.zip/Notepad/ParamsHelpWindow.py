helpWindowGeometry = "350x250"
textHelpWindow = "Программу разработал Митюшин Пётр"