from Interface import *
if __name__ == '__main__':
    interface = Interfece()



